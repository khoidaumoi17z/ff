import Foundation
import CryptoKit

enum InspectorError: LocalizedError {
    case tooLarge, limitReached
    var errorDescription: String? {
        switch self {
        case .tooLarge: return "Tệp vượt quá giới hạn 8 MiB."
        case .limitReached: return "Đã có 6 tệp. Hãy xóa một tệp trước khi nhập thêm."
        }
    }
}

struct FileRecord: Codable, Sendable {
    let id: UUID
    let name: String
    let importedAt: Date
}

struct InspectedFile: Identifiable, Sendable {
    static let maximumBytes = 8 * 1024 * 1024
    let record: FileRecord
    let data: Data
    let digest: String
    let jsonStatus: String
    let jsonValid: Bool
    let jsonPreview: String?
    let rootKeys: [String]
    let strings: [String]
    let totalStrings: Int
    let signals: [String]
    var id: UUID { record.id }
    var name: String { record.name }

    init(record: FileRecord, data: Data) throws {
        guard data.count <= Self.maximumBytes else { throw InspectorError.tooLarge }
        self.record = record
        self.data = data
        digest = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()

        do {
            let value = try JSONSerialization.jsonObject(with: data, options: [.fragmentsAllowed])
            let formatted = try JSONSerialization.data(withJSONObject: value,
                options: [.prettyPrinted, .sortedKeys, .fragmentsAllowed])
            let fullText = String(decoding: formatted, as: UTF8.self)
            jsonPreview = String(fullText.prefix(32_768))
                + (fullText.count > 32_768 ? "\n… Phần xem trước đã được rút gọn." : "")
            jsonValid = true
            if let dict = value as? [String: Any] {
                jsonStatus = "JSON hợp lệ · \(dict.count) khóa cấp đầu"
                rootKeys = dict.keys.sorted()
            } else if let array = value as? [Any] {
                jsonStatus = "JSON hợp lệ · mảng \(array.count) phần tử"
                rootKeys = []
            } else {
                jsonStatus = "JSON hợp lệ · giá trị đơn"
                rootKeys = []
            }
        } catch {
            jsonStatus = "Không phải JSON hợp lệ: \(error.localizedDescription)"
            jsonPreview = nil
            jsonValid = false
            rootKeys = []
        }

        var collected: [String] = []
        var count = 0
        var run: [UInt8] = []
        var runLength = 0
        func finishRun() {
            if runLength >= 5 {
                count += 1
                if collected.count < 128 {
                    let text = String(decoding: run, as: UTF8.self)
                    collected.append(text + (runLength > run.count ? "…" : ""))
                }
            }
            run.removeAll(keepingCapacity: true)
            runLength = 0
        }
        for byte in data {
            if (32...126).contains(byte) {
                runLength += 1
                if run.count < 384 { run.append(byte) }
            } else { finishRun() }
        }
        finishRun()
        strings = collected
        totalStrings = count

        // These are literal indicators, never a verdict about behavior.
        let indicators = ["IFix", "Assembly-CSharp", "WorldToScreenPoint", "CurrentLocalPlayer",
            "UnityEngine", "headshot", "aimbot", "espColor", "__espname", "hmEspBox"]
        signals = indicators.filter {
            data.range(of: Data($0.utf8)) != nil
        }
    }

    var hexadecimalPreview: String {
        let bytes = Array(data.prefix(256))
        return stride(from: 0, to: bytes.count, by: 16).map { start in
            let end = min(start + 16, bytes.count)
            return String(format: "%04X", start) + "  "
                + bytes[start..<end].map { String(format: "%02X", $0) }.joined(separator: " ")
        }.joined(separator: "\n")
    }

    var report: String {
        """
        VNBAPEX Inspector — báo cáo tệp
        Tên: \(name)
        Dung lượng: \(data.count) byte
        SHA-256: \(digest)
        Ngày nhập: \(record.importedAt.ISO8601Format())

        JSON: \(jsonStatus)
        Chuỗi ASCII từ 5 ký tự: \(totalStrings)
        Dấu vết tên: \(signals.isEmpty ? "Không tìm thấy trong danh sách kiểm tra" : signals.joined(separator: ", "))

        Dấu vết tên không chứng minh chức năng hoạt động.
        SHA-256 dùng để đối chiếu dữ liệu, không xác nhận tác giả hoặc độ an toàn.
        Ứng dụng chỉ đọc bản sao tệp; không thực thi nội dung.

        --- JSON xem trước ---
        \(jsonPreview ?? "Không có")

        --- Chuỗi ASCII xem trước (tối đa 128 chuỗi, 384 ký tự/chuỗi) ---
        \(strings.joined(separator: "\n"))
        """
    }
}

struct ByteComparison: Sendable {
    let identical: Bool
    let differentAtSharedOffsets: Int
    let trailingBytesInLeft: Int
    let trailingBytesInRight: Int
    let firstOffsets: [Int]

    static func compare(_ left: Data, _ right: Data) -> Self {
        var different = 0
        var offsets: [Int] = []
        let shared = min(left.count, right.count)
        if shared > 0 {
            for index in 0..<shared where left[index] != right[index] {
                different += 1
                if offsets.count < 16 { offsets.append(index) }
            }
        }
        let extraLeft = max(0, left.count - right.count)
        let extraRight = max(0, right.count - left.count)
        return Self(identical: different == 0 && extraLeft == 0 && extraRight == 0,
            differentAtSharedOffsets: different, trailingBytesInLeft: extraLeft,
            trailingBytesInRight: extraRight, firstOffsets: offsets)
    }
}

actor FileRepository {
    private let root: URL
    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        root = base.appendingPathComponent("InspectorFiles", isDirectory: true)
    }

    func restore() throws -> [InspectedFile] {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let files = try FileManager.default.contentsOfDirectory(at: root,
            includingPropertiesForKeys: nil).filter { $0.pathExtension == "json" }.sorted { $0.lastPathComponent < $1.lastPathComponent }
        guard files.count <= 6 else { throw InspectorError.limitReached }
        var results: [InspectedFile] = []
        for file in files {
            let record = try JSONDecoder().decode(FileRecord.self, from: Data(contentsOf: file))
            guard file.deletingPathExtension().lastPathComponent == record.id.uuidString else { continue }
            let data = try boundedRead(root.appendingPathComponent(record.id.uuidString + ".bin"))
            results.append(try InspectedFile(record: record, data: data))
        }
        return results.sorted { $0.record.importedAt > $1.record.importedAt }
    }

    func importFile(_ url: URL) throws -> InspectedFile {
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        let data = try boundedRead(url)
        return try save(name: url.lastPathComponent, data: data)
    }

    func sample() throws -> InspectedFile {
        let data = Data("{\"label\":\"Mẫu kiểm thử\",\"preview\":true,\"lineWidth\":2}".utf8)
        return try save(name: "sample-config.json", data: data)
    }

    private func save(name: String, data: Data) throws -> InspectedFile {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let existing = try FileManager.default.contentsOfDirectory(at: root,
            includingPropertiesForKeys: nil).filter { $0.pathExtension == "json" }
        guard existing.count < 6 else { throw InspectorError.limitReached }
        let record = FileRecord(id: UUID(), name: name, importedAt: Date())
        let file = try InspectedFile(record: record, data: data)
        let binary = root.appendingPathComponent(record.id.uuidString + ".bin")
        let metadata = root.appendingPathComponent(record.id.uuidString + ".json")
        try data.write(to: binary, options: [.atomic, .completeFileProtection])
        do {
            try JSONEncoder().encode(record).write(to: metadata,
                options: [.atomic, .completeFileProtection])
        } catch {
            try? FileManager.default.removeItem(at: binary)
            throw error
        }
        return file
    }

    func remove(_ id: UUID) throws {
        // Remove metadata first so a partially deleted entry cannot break restore.
        let metadata = root.appendingPathComponent(id.uuidString + ".json")
        let binary = root.appendingPathComponent(id.uuidString + ".bin")
        if FileManager.default.fileExists(atPath: metadata.path) { try FileManager.default.removeItem(at: metadata) }
        if FileManager.default.fileExists(atPath: binary.path) { try FileManager.default.removeItem(at: binary) }
    }

    private func boundedRead(_ url: URL) throws -> Data {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var data = Data()
        while let chunk = try handle.read(upToCount: 64 * 1024), !chunk.isEmpty {
            guard data.count + chunk.count <= InspectedFile.maximumBytes else { throw InspectorError.tooLarge }
            data.append(chunk)
        }
        return data
    }
}
