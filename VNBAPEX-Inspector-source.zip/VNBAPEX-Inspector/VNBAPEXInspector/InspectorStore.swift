import SwiftUI

@MainActor
final class InspectorStore: ObservableObject {
    @Published var files: [InspectedFile] = []
    @Published var busy = false
    @Published var errorMessage: String?
    private let repository = FileRepository()
    private var restored = false

    func restore() async {
        guard !restored else { return }
        restored = true
        busy = true
        defer { busy = false }
        do { files = try await repository.restore() }
        catch { errorMessage = "Không thể khôi phục tệp: " + error.localizedDescription }
    }

    func importFile(_ url: URL) async {
        guard !busy else { return }
        busy = true
        defer { busy = false }
        do {
            let file = try await repository.importFile(url)
            files.insert(file, at: 0)
        }
        catch { errorMessage = error.localizedDescription }
    }

    func addSample() async {
        guard !busy else { return }
        busy = true
        defer { busy = false }
        do {
            let file = try await repository.sample()
            files.insert(file, at: 0)
        }
        catch { errorMessage = error.localizedDescription }
    }

    func remove(_ id: UUID) async {
        guard !busy else { return }
        busy = true
        defer { busy = false }
        do {
            try await repository.remove(id)
            files.removeAll { $0.id == id }
        } catch { errorMessage = error.localizedDescription }
    }
}
