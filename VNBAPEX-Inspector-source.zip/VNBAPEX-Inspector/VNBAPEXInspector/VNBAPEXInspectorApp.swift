import SwiftUI
import UniformTypeIdentifiers

@main
@MainActor
struct VNBAPEXInspectorApp: App {
    @StateObject private var store = InspectorStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .tint(.mint)
                .preferredColorScheme(.dark)
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var store: InspectorStore
    var body: some View {
        TabView {
            FilesView().tabItem { Label("Tệp", systemImage: "doc.text.magnifyingglass") }
            CompareView().tabItem { Label("So sánh", systemImage: "square.on.square") }
            PreviewLabView().tabItem { Label("Mô phỏng", systemImage: "viewfinder") }
        }
        .task { await store.restore() }
        .alert("Không thể hoàn tất", isPresented: Binding(
            get: { store.errorMessage != nil },
            set: { if !$0 { store.errorMessage = nil } })) {
                Button("Đóng", role: .cancel) { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
    }
}

struct FilesView: View {
    @EnvironmentObject private var store: InspectorStore
    @State private var importing = false
    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("VNBAPEX").font(.caption.bold()).foregroundStyle(.mint)
                        Text("Inspector").font(.largeTitle.bold())
                        Text("Xem cấu trúc. Đối chiếu dữ liệu.").foregroundStyle(.secondary)
                        Label("Xử lý trên thiết bị", systemImage: "iphone").font(.caption)
                    }.padding(.vertical, 12)
                }
                Section {
                    Button { importing = true } label: {
                        Label("Nhập patch hoặc cấu hình", systemImage: "plus.circle.fill")
                    }.disabled(store.busy || store.files.count >= 6)
                    Button { Task { await store.addSample() } } label: {
                        Label("Thử với tệp mẫu", systemImage: "sparkles")
                    }.disabled(store.busy || store.files.count >= 6)
                    if store.busy { ProgressView("Đang xử lý…") }
                } footer: { Text("Tối đa 6 tệp, mỗi tệp 8 MiB. Bản sao được lưu trong ứng dụng.") }
                Section("Tệp đã nhập · \(store.files.count)") {
                    if store.files.isEmpty {
                        Text("Chọn tệp trong ứng dụng Tệp để bắt đầu.")
                            .foregroundStyle(.secondary).padding(.vertical, 12)
                    }
                    ForEach(store.files) { file in
                        NavigationLink {
                            DetailView(file: file)
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(file.name).font(.headline).lineLimit(2)
                                Text(ByteCountFormatter.string(fromByteCount: Int64(file.data.count), countStyle: .file))
                                    .font(.caption).foregroundStyle(.secondary)
                                Text(file.jsonValid ? "JSON hợp lệ" : "Tệp nhị phân / văn bản khác")
                                    .font(.caption).foregroundStyle(file.jsonValid ? Color.mint : Color.secondary)
                            }.padding(.vertical, 5)
                        }
                        .swipeActions {
                            Button("Xóa", role: .destructive) { Task { await store.remove(file.id) } }
                                .disabled(store.busy)
                        }
                    }
                }
            }
            .navigationTitle("Kiểm tra tệp")
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(isPresented: $importing, allowedContentTypes: [.data],
                allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    if let url = urls.first { Task { await store.importFile(url) } }
                case .failure(let error): store.errorMessage = error.localizedDescription
                }
            }
        }
    }
}

struct DetailView: View {
    let file: InspectedFile
    var body: some View {
        List {
            Section("Thông tin") {
                LabeledContent("Tên", value: file.name)
                LabeledContent("Dung lượng", value: "\(file.data.count) byte")
                LabeledContent("Ngày nhập", value: file.record.importedAt.formatted(date: .abbreviated, time: .shortened))
            }
            Section("SHA-256") {
                Text(file.digest).font(.system(.footnote, design: .monospaced))
                    .textSelection(.enabled)
            } footer: { Text("Mã băm dùng để đối chiếu dữ liệu; không xác nhận nguồn gốc hoặc độ an toàn.") }
            Section("Cấu trúc JSON") {
                Text(file.jsonStatus).font(.footnote)
                if let preview = file.jsonPreview {
                    DisclosureGroup("Xem nội dung") {
                        ScrollView(.horizontal) {
                            Text(preview).font(.system(.caption, design: .monospaced))
                                .textSelection(.enabled).padding(.vertical, 8)
                        }
                    }
                }
            }
            Section("Dấu vết tên") {
                if file.signals.isEmpty { Text("Không tìm thấy tên trong danh sách kiểm tra.").foregroundStyle(.secondary) }
                ForEach(file.signals, id: \.self) { Text($0).font(.system(.footnote, design: .monospaced)) }
            } footer: { Text("Tên xuất hiện trong dữ liệu chưa chứng minh chức năng tương ứng hoạt động.") }
            Section("Chuỗi ASCII · \(file.totalStrings)") {
                DisclosureGroup("Xem tối đa 128 chuỗi") {
                    ForEach(Array(file.strings.enumerated()), id: \.offset) { item in
                        Text(item.element).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                    }
                }
            }
            Section("256 byte đầu") {
                ScrollView(.horizontal) {
                    Text(file.hexadecimalPreview.isEmpty ? "Tệp rỗng" : file.hexadecimalPreview)
                        .font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                }
            }
            Section {
                ShareLink(item: file.report) {
                    Label("Chia sẻ báo cáo văn bản", systemImage: "square.and.arrow.up")
                }
            }
        }
        .navigationTitle("Chi tiết tệp")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct CompareView: View {
    @EnvironmentObject private var store: InspectorStore
    @State private var leftID: UUID?
    @State private var rightID: UUID?
    @State private var comparison: ByteComparison?
    @State private var comparing = false
    private var left: InspectedFile? { store.files.first { $0.id == leftID } }
    private var right: InspectedFile? { store.files.first { $0.id == rightID } }
    var body: some View {
        NavigationStack {
            List {
                Section("Hai bản dữ liệu") {
                    filePicker("Bản A", selection: $leftID)
                    filePicker("Bản B", selection: $rightID)
                    Button {
                        guard let a = left, let b = right else { return }
                        comparing = true
                        Task {
                            let result = await Task.detached(priority: .userInitiated) {
                                ByteComparison.compare(a.data, b.data)
                            }.value
                            if leftID == a.id, rightID == b.id,
                               store.files.contains(where: { $0.id == a.id }),
                               store.files.contains(where: { $0.id == b.id }) {
                                comparison = result
                            } else { comparison = nil }
                            comparing = false
                        }
                    } label: { Label("So sánh byte", systemImage: "arrow.left.arrow.right") }
                    .disabled(left == nil || right == nil || comparing || store.busy)
                    if comparing { ProgressView("Đang so sánh…") }
                }
                if let result = comparison {
                    Section("Kết quả") {
                        Label(result.identical ? "Hai tệp giống hệt" : "Hai tệp khác nhau",
                              systemImage: result.identical ? "checkmark.circle" : "circle.lefthalf.filled")
                            .foregroundStyle(result.identical ? Color.mint : Color.orange)
                        LabeledContent("Byte khác tại cùng offset", value: "\(result.differentAtSharedOffsets)")
                        LabeledContent("Byte dư ở cuối A", value: "\(result.trailingBytesInLeft)")
                        LabeledContent("Byte dư ở cuối B", value: "\(result.trailingBytesInRight)")
                        if !result.firstOffsets.isEmpty {
                            Text("Offset đầu tiên: " + result.firstOffsets.map { String(format: "0x%X", $0) }.joined(separator: ", "))
                                .font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                        }
                    } footer: {
                        Text("So sánh theo vị trí byte, không phải so sánh ý nghĩa JSON. Chèn một byte có thể làm nhiều offset khác nhau.")
                    }
                } else {
                    Section { Text("Nhập hai tệp ở tab Tệp, rồi chọn A và B.").foregroundStyle(.secondary) }
                }
            }
            .navigationTitle("So sánh")
            .onChange(of: leftID) { _ in comparison = nil }
            .onChange(of: rightID) { _ in comparison = nil }
            .onChange(of: store.files.map(\.id)) { ids in
                if let id = leftID, !ids.contains(id) { leftID = nil }
                if let id = rightID, !ids.contains(id) { rightID = nil }
                comparison = nil
            }
        }
    }
    private func filePicker(_ title: String, selection: Binding<UUID?>) -> some View {
        Picker(title, selection: selection) {
            Text("Chọn tệp").tag(Optional<UUID>.none)
            ForEach(store.files) { file in
                Text(file.name + " · " + String(file.digest.prefix(6))).tag(Optional(file.id))
            }
        }.disabled(comparing)
    }
}

struct PreviewLabView: View {
    @State private var boxes = true
    @State private var names = true
    @State private var lines = false
    @State private var lineWidth = 2.0
    @State private var color = Color.mint
    private let points: [CGPoint] = [CGPoint(x: 0.25, y: 0.50), CGPoint(x: 0.56, y: 0.36), CGPoint(x: 0.78, y: 0.57)]
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Canvas { context, size in
                        var grid = Path()
                        for x in stride(from: CGFloat(0), through: size.width, by: 24) {
                            grid.move(to: CGPoint(x: x, y: 0)); grid.addLine(to: CGPoint(x: x, y: size.height))
                        }
                        for y in stride(from: CGFloat(0), through: size.height, by: 24) {
                            grid.move(to: CGPoint(x: 0, y: y)); grid.addLine(to: CGPoint(x: size.width, y: y))
                        }
                        context.stroke(grid, with: .color(.white.opacity(0.06)), lineWidth: 1)
                        for (index, point) in points.enumerated() {
                            let center = CGPoint(x: point.x * size.width, y: point.y * size.height)
                            let rect = CGRect(x: center.x - 20, y: center.y - 36, width: 40, height: 72)
                            if boxes { context.stroke(Path(rect), with: .color(color), lineWidth: CGFloat(lineWidth)) }
                            if names {
                                context.draw(Text("Mẫu \(index + 1)").font(.caption2).foregroundColor(color),
                                    at: CGPoint(x: center.x, y: rect.minY - 12))
                            }
                            if lines {
                                var path = Path(); path.move(to: CGPoint(x: size.width / 2, y: size.height))
                                path.addLine(to: CGPoint(x: center.x, y: rect.maxY))
                                context.stroke(path, with: .color(color.opacity(0.65)), lineWidth: 1)
                            }
                        }
                    }
                    .frame(height: 250)
                    .accessibilityLabel("Bản mô phỏng ba đối tượng cố định")
                } footer: { Text("Dữ liệu mẫu cố định do ứng dụng tự tạo. Không lấy dữ liệu từ game.") }
                Section("Tùy chỉnh hình vẽ") {
                    Toggle("Khung", isOn: $boxes)
                    Toggle("Nhãn", isOn: $names)
                    Toggle("Đường nối", isOn: $lines)
                    ColorPicker("Màu", selection: $color, supportsOpacity: false)
                    VStack(alignment: .leading) {
                        Text("Độ dày · \(Int(lineWidth))")
                        Slider(value: $lineWidth, in: 1...5, step: 1)
                    }
                }
            }
            .navigationTitle("Phòng mô phỏng")
        }
    }
}
